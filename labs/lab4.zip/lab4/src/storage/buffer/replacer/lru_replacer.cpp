/*------------------------------------------------------------------------------
 - Copyright (c) 2024. Websoft research group, Nanjing University.
 -
 - This program is free software: you can redistribute it and/or modify
 - it under the terms of the GNU General Public License as published by
 - the Free Software Foundation, either version 3 of the License, or
 - (at your option) any later version.
 -
 - This program is distributed in the hope that it will be useful,
 - but WITHOUT ANY WARRANTY; without even the implied warranty of
 - MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 - GNU General Public License for more details.
 -
 - You should have received a copy of the GNU General Public License
 - along with this program.  If not, see <https://www.gnu.org/licenses/>.
 -----------------------------------------------------------------------------*/

//
// Created by ziqi on 2024/7/17.
//

#include "lru_replacer.h"
#include "common/config.h"
#include "../common/error.h"
namespace wsdb {

LRUReplacer::LRUReplacer() : cur_size_(0), max_size_(BUFFER_POOL_SIZE) {}

auto LRUReplacer::Victim(frame_id_t *frame_id) -> bool
{
  std::lock_guard<std::mutex> lock(latch_);

  if (cur_size_ <= 0) {
    *frame_id = INVALID_FRAME_ID;
    return false;
  }

  for (auto vic = lru_list_.rbegin(); vic != lru_list_.rend(); vic++) {
    if (vic->second) {
      *frame_id = vic->first;
      lru_hash_.erase(vic->first);
      lru_list_.erase(std::next(vic).base());
      if (cur_size_ > 0)
        cur_size_--;
      return true;
    }
  }

  return false;
}

void LRUReplacer::Pin(frame_id_t frame_id)
{
  std::lock_guard<std::mutex> lock(latch_);

  auto hash_itr = lru_hash_.find(frame_id);
  if (hash_itr != lru_hash_.end()) {
    auto list_itr = hash_itr->second;
    lru_list_.splice(lru_list_.begin(), lru_list_, list_itr);
    if (list_itr->second) {
      list_itr->second = false;
      if (cur_size_ > 0)
        cur_size_--;
    }
  } else {
    lru_list_.emplace_front(frame_id, false);
    lru_hash_[frame_id] = lru_list_.begin();
  }
}

void LRUReplacer::Unpin(frame_id_t frame_id)
{
  std::lock_guard<std::mutex> lock(latch_);
  auto hash_itr = lru_hash_.find(frame_id);
  if (hash_itr != lru_hash_.end() && !hash_itr->second->second) {
    hash_itr->second->second = true;
    cur_size_++;
  }
}

auto LRUReplacer::Size() -> size_t
{
  std::lock_guard<std::mutex> lock(latch_);

  return cur_size_;
}

}  // namespace wsdb
