-- 姓名：张路远
-- 学号：221220144
-- 提交前请确保本次实验独立完成，若有参考请注明并致谢。

-- ____________________________________________________________________________________________________________________________________________________________________________________________________________
-- BEGIN Q1
WITH words AS(
    SELECT *
    FROM species s
    WHERE s.description REGEXP '\\bthis\\b'
)
SELECT COUNT(*) AS speciesCount
FROM words;
-- END Q1

-- ____________________________________________________________________________________________________________________________________________________________________________________________________________
-- BEGIN Q2
SELECT pl.username,
    SUM(ph.power) AS totalPhonemonPower
FROM player pl
    JOIN phonemon ph ON pl.id = ph.player
WHERE pl.username IN ('Cook', 'Hughes')
GROUP BY pl.id;
-- END Q2

-- ____________________________________________________________________________________________________________________________________________________________________________________________________________
-- BEGIN Q3
SELECT t.title,
    COUNT(pl.id) AS numberOfPlayers
FROM team t
    JOIN player pl ON t.id = pl.team
GROUP BY t.id,
    t.title
ORDER BY numberOfPlayers DESC;
-- END Q3

-- ____________________________________________________________________________________________________________________________________________________________________________________________________________
-- BEGIN Q4
SELECT s.id AS idSpecies,
    s.title
FROM species s
WHERE s.type1 = 12
    OR s.type2 = 12;
-- END Q4

-- ____________________________________________________________________________________________________________________________________________________________________________________________________________
-- BEGIN Q5
SELECT pl.id AS idPlayer,
    pl.username
FROM player pl
WHERE pl.id NOT IN (
        SELECT pl_.id
        FROM player pl_
            JOIN purchase p_ ON pl_.id = p_.player
            JOIN item i_ ON p_.item = i_.id
        WHERE i_.type = 'F'
    )
ORDER BY pl.id;
-- END Q5

-- ____________________________________________________________________________________________________________________________________________________________________________________________________________
-- BEGIN Q6
SELECT pl.level,
    SUM(p.quantity * i.price) AS totalAmountSpentByAllPlayersAtLevel
FROM player pl
    JOIN purchase p ON p.player = pl.id
    JOIN item i ON p.item = i.id
GROUP BY pl.level
ORDER BY totalAmountSpentByAllPlayersAtLevel DESC;
-- END Q6

-- ____________________________________________________________________________________________________________________________________________________________________________________________________________
-- BEGIN Q7
SELECT p.item,
    i.title,
    COUNT(*) AS numTimesPurchased
FROM purchase p
    JOIN item i ON p.item = i.id
GROUP BY p.item,
    i.title
HAVING numTimesPurchased = (
        SELECT MAX(totalPurchases)
        FROM (
                SELECT COUNT(*) AS totalPurchases
                FROM purchase p_
                GROUP BY p_.item
            ) AS purchaseCounts
    );
-- END Q7

-- ____________________________________________________________________________________________________________________________________________________________________________________________________________
-- BEGIN Q8
WITH TotalFood AS (
    SELECT COUNT(*) AS numberDistinctFoodItemsPurchased
    FROM item i
    WHERE i.type = 'F'
),
ID_Username_FoodNum AS (
    SELECT p.player AS playerID,
        pl.username,
        COUNT(DISTINCT i.id) AS FoodNum
    FROM purchase p
        JOIN player pl ON p.player = pl.id
        JOIN item i ON p.item = i.id
    WHERE i.type = 'F'
    GROUP BY pl.id
)
SELECT iuf.playerID,
    iuf.username,
    tf.numberDistinctFoodItemsPurchased
FROM ID_Username_FoodNum iuf
    RIGHT JOIN TotalFood tf ON iuf.FoodNum = tf.tf.numberDistinctFoodItemsPurchased;
-- END Q8

-- ____________________________________________________________________________________________________________________________________________________________________________________________________________
-- BEGIN Q9
WITH AllDis AS (
    SELECT ph1.id AS id1,
        ph2.id AS id2,
        100 * SQRT(
            POW(ph1.latitude - ph2.latitude, 2) + POW(ph1.longitude - ph2.longitude, 2)
        ) AS dis
    FROM phonemon ph1
        JOIN phonemon ph2 ON ph1.id < ph2.id
),
MinDis AS (
    SELECT MIN(ad.dis) AS mindis
    FROM AllDis ad
)
SELECT COUNT(*) AS numberOfPhonemonPairs,
    (
        SELECT ROUND(mindis, 2)
        FROM MinDis
    ) AS distanceX
FROM AllDis ad
    JOIN MinDis md ON ad.dis = (
        SELECT mindis
        FROM MinDis
    );
-- END Q9

-- ____________________________________________________________________________________________________________________________________________________________________________________________________________
-- BEGIN Q10
WITH TypeNum AS (
    SELECT t.id,
        t.title,
        COUNT(s.id) AS num
    FROM type t
        LEFT JOIN species s ON s.type1 = t.id
        OR s.type2 = t.id
    GROUP BY t.id
),
PlayerTypeCount AS (
    SELECT pl.id AS PlayerID,
        t.id AS TypeID,
        COUNT(DISTINCT s.id) AS TypeNum
    FROM player pl
        JOIN type t ON 1 = 1
        JOIN species s ON s.type1=t.id OR s.type2=t.id
        JOIN phonemon ph ON pl.id = ph.player
        AND ph.species=s.id
    GROUP BY pl.id,
        t.id
)
SELECT pl.username,
    t.title
FROM PlayerTypeCount ptc
    JOIN player pl ON ptc.PlayerID = pl.id
    JOIN type t ON ptc.TypeID = t.id
    JOIN TypeNum tn ON tn.id = t.id
WHERE ptc.TypeNum = tn.num;
-- END Q10