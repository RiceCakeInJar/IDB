import pymysql
import sys
from prettytable import PrettyTable

department_name = sys.argv[1]

connection = pymysql.connect(
    host='localhost',
    user='root',
    password='zcy11140228',
    database='orderdb'
)
cursor = connection.cursor()

cursor.execute(f"SELECT employeeNo, employeeName, salary FROM Employee WHERE department = '{department_name}'")
results = cursor.fetchall()
table = PrettyTable()
table.field_names = ["员工编号", "员工姓名", "薪资"]
for row in results:
    table.add_row(row)
print(f"\n--- {department_name}旧薪资表: {department_name} ---")
print(table)

cursor.execute(f"""
UPDATE Employee
SET salary = salary + 200
WHERE department = '{department_name}'
""")
connection.commit()

cursor.execute(f"SELECT employeeNo, employeeName, salary FROM Employee WHERE department = '{department_name}'")
results = cursor.fetchall()
table = PrettyTable()
table.field_names = ["员工编号", "员工姓名", "薪资"]
for row in results:
    table.add_row(row)
print(f"\n--- {department_name}新薪资表: {department_name} ---")
print(table)

# 关闭数据库连接
cursor.close()
connection.close()