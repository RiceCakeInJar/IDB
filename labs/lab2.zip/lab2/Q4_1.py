import pymysql
from prettytable import PrettyTable

connection = pymysql.connect(
    host='localhost',
    user='root',
    password='zcy11140228',
    database='orderdb'
)

try:
    with connection.cursor() as cursor:
        query = """
        SELECT employeeNo, employeeName, salary
        FROM Employee
        ORDER BY salary DESC
        LIMIT 20;
        """
        cursor.execute(query)
        results = cursor.fetchall()
        
        table = PrettyTable()
        table.field_names = ["员工编号", "姓名", "工资"]
        for row in results:
            table.add_row(row)
        
        print(table)

finally:
    connection.close()
