import pymysql
from prettytable import PrettyTable

connection = pymysql.connect(
    host='localhost',
    user='root',
    password='zcy11140228',
    database='orderdb'
)

try:
    with connection.cursor() as cursor:
        query_all = """
        SELECT employeeNo, employeeName, salary
        FROM Employee;
        """

        cursor.execute(query_all)
        results_before = cursor.fetchall()
        table_before = PrettyTable(["员工编号", "员工姓名", "薪水"])
        for row in results_before:
            table_before.add_row(row)
        print("删除前的员工信息：")
        print(table_before)
        print("\n")

        delete_query = """
        DELETE FROM Employee 
        WHERE salary > 5000;
        """
        cursor.execute(delete_query)
        connection.commit()
        print("已删除薪水高于5000的员工信息\n")

        cursor.execute(query_all)
        results_after = cursor.fetchall()
        table_after = PrettyTable(["员工编号", "员工姓名", "薪水"])
        for row in results_after:
            table_after.add_row(row)
        print("删除后的员工信息：")
        print(table_after)

finally:
    connection.close()