import pymysql
from prettytable import PrettyTable

connection = pymysql.connect(
    host='localhost',
    user='root',
    password='zcy11140228',
    database='orderdb'
)

try:
    with connection.cursor() as cursor:
        query_all = """
        SELECT customerNo, customerName, address, telephone, zip
        FROM Customer;
        """

        cursor.execute(query_all)
        results_before = cursor.fetchall()
        table_before = PrettyTable(["客户编号", "客户名称", "地址", "电话", "邮编"])
        for row in results_before:
            table_before.add_row(row)
        print("插入前的客户表信息：")
        print(table_before)
        print("\n")

        insert_query = """
        INSERT INTO Customer (customerNo, customerName, address, telephone, zip) 
        VALUES ('C20080002', '泰康股份有限公司', '天津市', '010-5422685', '220501');
        """
        cursor.execute(insert_query)
        connection.commit()
        print("已插入新客户信息\n")

        cursor.execute(query_all)
        results_after = cursor.fetchall()
        table_after = PrettyTable(["客户编号", "客户名称", "电话", "地址", "邮编"])
        for row in results_after:
            table_after.add_row(row)
        print("插入后的客户表信息：")
        print(table_after)

finally:
    connection.close()