import pymysql
from prettytable import PrettyTable

connection = pymysql.connect(
    host='localhost',
    user='root',
    password='zcy11140228',
    database='orderdb'
)
cursor = connection.cursor()

cursor.execute("SELECT customerName, address, telephone FROM Customer")
table = PrettyTable()
table.field_names = ["客户姓名", "客户地址", "客户电话"]
while True:
    row = cursor.fetchone()
    if row is None:
        break
    table.add_row(row)
print("\n--- 客户信息表 ---")
print(table)

cursor.close()
connection.close()
