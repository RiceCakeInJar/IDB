import pymysql
from prettytable import PrettyTable

connection = pymysql.connect(
    host='localhost',
    user='root',
    password='zcy11140228',
    database='orderdb'
)

try:
    with connection.cursor() as cursor:
        query_all = """
        SELECT productNo, productName, productPrice
        FROM Product;
        """

        cursor.execute(query_all)
        results_before = cursor.fetchall()
        table_before = PrettyTable(["商品编号", "商品名称", "价格"])
        for row in results_before:
            table_before.add_row(row)
        print("更新前的商品与价格信息：")
        print(table_before)
        print("\n")

        update_query = """
        UPDATE Product 
        SET productPrice = productPrice * 0.5 
        WHERE productPrice > 1000;
        """
        cursor.execute(update_query)
        connection.commit()
        print("已更新价格超过1000的商品价格为原来的50%\n")

        cursor.execute(query_all)
        results_after = cursor.fetchall()
        table_after = PrettyTable(["商品编号", "商品名称", "价格"])
        for row in results_after:
            table_after.add_row(row)
        print("更新后的商品与价格信息：")
        print(table_after)

finally:
    connection.close()