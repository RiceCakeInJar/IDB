-- 姓名：张路远
-- 学号：221220144
-- 提交前请确保本次实验独立完成，若有参考请注明并致谢。

-- ____________________________________________________________________________________________________________________________________________________________________________________________________________
-- BEGIN Q1.1

CREATE PROCEDURE GetCustomerOrderDetailsByProduct(
    IN inputProductName VARCHAR(40)
)
BEGIN
    SELECT 
        c.customerNo AS CustomerID,
        c.customerName AS CustomerName,
        om.orderNo AS OrderID,
        od.quantity AS OrderQuantity,
        (od.quantity * od.price) AS OrderAmount
    FROM 
        Customer c
    JOIN 
        OrderMaster om ON c.customerNo = om.customerNo
    JOIN 
        OrderDetail od ON om.orderNo = od.orderNo
    JOIN 
        Product p ON od.productNo = p.productNo
    WHERE 
        p.productName = inputProductName
    ORDER BY 
        OrderAmount DESC;
END

CALL GetCustomerOrderDetailsByProduct('32M DRAM');

-- END Q1.1

-- ____________________________________________________________________________________________________________________________________________________________________________________________________________
-- BEGIN Q1.2

CREATE PROCEDURE GetEarlierHiredEmployees(
    IN inputEmployeeNo CHAR(8)
)
BEGIN
    SELECT 
        e1.employeeNo AS EmployeeID,
        e1.employeeName AS EmployeeName,
        e1.gender AS Gender,
        e1.hireDate AS HireDate,
        e1.department AS Department
    FROM 
        Employee e1
    JOIN 
        Employee e2 ON e1.department = e2.department
    WHERE 
        e2.employeeNo = inputEmployeeNo
        AND e1.hireDate < e2.hireDate;
END

CALL GetEarlierHiredEmployees('E2008005');

-- END Q1.2

-- ____________________________________________________________________________________________________________________________________________________________________________________________________________
-- BEGIN Q2.1

CREATE FUNCTION GetAverageOrderPriceByProduct(productName VARCHAR(40))
RETURNS DECIMAL(10, 2)
DETERMINISTIC
BEGIN
    RETURN(
        SELECT IFNULL(SUM(od.price * od.quantity) / SUM(od.quantity), 0)
            FROM OrderDetail od
            JOIN Product p ON od.productNo = p.productNo
            WHERE p.productName = productName
    );
END

SELECT 
    p.productName AS ProductName,
    GetAverageOrderPriceByProduct(p.productName) AS AverageOrderPrice
FROM 
    Product p;

-- END Q2.1

-- ____________________________________________________________________________________________________________________________________________________________________________________________________________
-- BEGIN Q2.2

CREATE FUNCTION GetTotalSalesByProduct(productNo CHAR(9))
RETURNS INT
DETERMINISTIC
BEGIN
    RETURN(
        SELECT IFNULL(SUM(od.quantity), 0)
        FROM OrderDetail od
        WHERE od.productNo = productNo
    );
END

SELECT 
    p.productNo AS ProductID,
    p.productName AS ProductName,
    GetTotalSalesByProduct(p.productNo) AS TotalSales
FROM 
    Product p
WHERE 
    GetTotalSalesByProduct(p.productNo) > 4;

-- END Q2.2

-- ____________________________________________________________________________________________________________________________________________________________________________________________________________
-- BEGIN Q3.1

CREATE TRIGGER SetProductPriceBeforeInsert
BEFORE INSERT ON Product
FOR EACH ROW
SET NEW.productPrice = LEAST(NEW.productPrice, 1000);

-- END Q3.1

-- ____________________________________________________________________________________________________________________________________________________________________________________________________________
-- BEGIN Q3.2

CREATE TRIGGER UpdateEmployeeSalaryAfterOrder
AFTER INSERT ON OrderMaster
FOR EACH ROW
BEGIN
    UPDATE Employee 
    SET salary = salary * 
        IF(hireDate < '1992-01-01 00:00:00', 1.08, 1.05)
    WHERE employeeNo = NEW.employeeNo;
END

-- END Q3.2

