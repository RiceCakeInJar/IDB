/*------------------------------------------------------------------------------
 - Copyright (c) 2024. Websoft research group, Nanjing University.
 -
 - This program is free software: you can redistribute it and/or modify
 - it under the terms of the GNU General Public License as published by
 - the Free Software Foundation, either version 3 of the License, or
 - (at your option) any later version.
 -
 - This program is distributed in the hope that it will be useful,
 - but WITHOUT ANY WARRANTY; without even the implied warranty of
 - MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 - GNU General Public License for more details.
 -
 - You should have received a copy of the GNU General Public License
 - along with this program.  If not, see <https://www.gnu.org/licenses/>.
 -----------------------------------------------------------------------------*/

//
// Created by ziqi on 2024/7/17.
//
#include "buffer_pool_manager.h"
#include "replacer/lru_replacer.h"
#include "replacer/lru_k_replacer.h"

#include "../../../common/error.h"

namespace wsdb {

BufferPoolManager::BufferPoolManager(DiskManager *disk_manager, wsdb::LogManager *log_manager, size_t replacer_lru_k)
    : disk_manager_(disk_manager), log_manager_(log_manager)
{
  if (REPLACER == "LRUReplacer") {
    replacer_ = std::make_unique<LRUReplacer>();
  } else if (REPLACER == "LRUKReplacer") {
    replacer_ = std::make_unique<LRUKReplacer>(replacer_lru_k);
  } else {
    WSDB_FETAL("Unknown replacer: " + REPLACER);
  }
  // init free_list_
  for (frame_id_t i = 0; i < static_cast<int>(BUFFER_POOL_SIZE); i++) {
    free_list_.push_back(i);
  }
}

auto BufferPoolManager::FetchPage(file_id_t fid, page_id_t pid) -> Page *
{
  // 1. grant the latch
  std::lock_guard<std::mutex> lock(latch_);
  // 2. check if the page is in the frame
  auto it = page_frame_lookup_.find({fid, pid});
  // 3. if the page is not in the frame, GetAvailableFrame and UpdateFrame
  if (it == page_frame_lookup_.end()) {
    frame_id_t frame_id = GetAvailableFrame();
    UpdateFrame(frame_id, fid, pid);
    return frames_[frame_id].GetPage();
  }
  // 4. else pin the frame both in the buffer and the replacer and return the page
  frame_id_t frame_id = it->second;
  Frame     &frame    = frames_[frame_id];
  frame.Pin();
  replacer_->Pin(frame_id);
  return frame.GetPage();
}

auto BufferPoolManager::UnpinPage(file_id_t fid, page_id_t pid, bool is_dirty) -> bool
{
  // 1. grant the latch
  std::lock_guard<std::mutex> lock(latch_);
  // 2. if the frame is not in the buffer or the frame is not in use, return false
  auto frame_it = page_frame_lookup_.find({fid, pid});
  if (frame_it == page_frame_lookup_.end()) {
    return false;
  }
  frame_id_t frame_id = frame_it->second;
  if (!frames_[frame_id].InUse()) {
    return false;
  }
  // 3. unpin the frame, after that if the frame is not in use, unpin the frame in the replacer
  frames_[frame_id].Unpin();
  if (!frames_[frame_id].InUse()) {
    replacer_->Unpin(frame_id);
  }
  // 4. set the frame dirty if the page is dirty
  if (is_dirty) {
    frames_[frame_id].SetDirty(true);
  }
  return true;
}

auto BufferPoolManager::DeletePage(file_id_t fid, page_id_t pid) -> bool
{
  // 1. grant the latch
  std::lock_guard<std::mutex> lock(latch_);
  // 2. if the page is not in the buffer, return true
  auto it = page_frame_lookup_.find({fid, pid});
  if (it == page_frame_lookup_.end()) {
    return true;
  }
  // 3. if the page is in use, return false
  frame_id_t frame_id = it->second;
  Frame     &frame    = frames_[frame_id];
  if (frame.InUse()) {
    return false;
  }
  // 4. flush the page to disk if it's dirty
  if (frame.IsDirty()) {
    disk_manager_->WritePage(fid, pid, frame.GetPage()->GetData());
  }
  frame.Reset();                   // reset the frame
  free_list_.push_back(frame_id);  // add the frame to the free list
  replacer_->Unpin(frame_id);      // unpin the frame in the replacer
  // 5. update the page_frame_lookup_
  page_frame_lookup_.erase(it);
  return true;
}

auto BufferPoolManager::DeleteAllPages(file_id_t fid) -> bool
{
  bool all_deleted = true;
  for (auto it = page_frame_lookup_.begin(); it != page_frame_lookup_.end();) {
    if (it->first.fid == fid) {
      auto next_it = std::next(it);
      bool deleted = DeletePage(fid, it->first.pid);
      if (!deleted) {
        all_deleted = false;
        break;
      }
      it = next_it;
    } else {
      ++it;
    }
  }
  return all_deleted;
}

auto BufferPoolManager::FlushPage(file_id_t fid, page_id_t pid) -> bool
{
  // 1. grant the latch
  std::lock_guard<std::mutex> lock(latch_);
  // 2. if the page is not in the buffer, return false
  auto frame = GetFrame(fid, pid);
  if (!frame) {
    return false;
  }
  // 3. flush the page to disk if the page is dirty
  if (frame->IsDirty()) {
    disk_manager_->WritePage(fid, pid, frame->GetPage()->GetData());  // 将脏页写入磁盘
    frame->SetDirty(false);
  }
  return true;
}

auto BufferPoolManager::FlushAllPages(file_id_t fid) -> bool
{
  bool all_flushed = true;
  for (auto it = page_frame_lookup_.begin(); it != page_frame_lookup_.end(); ++it) {
    if (it->first.fid == fid) {
      bool flushed = FlushPage(fid, it->first.pid);
      if (!flushed) {
        all_flushed = false;
      }
    }
  }
  return all_flushed;
}

auto BufferPoolManager::GetAvailableFrame() -> frame_id_t
{
  // 1. if the free list is not empty, get the frame id from the free list
  if (!free_list_.empty()) {
    frame_id_t frame_id = free_list_.front();
    free_list_.pop_front();
    return frame_id;
  }
  // 2. else use the replacer to get the frame id
  frame_id_t frame_id;
  if (replacer_->Victim(&frame_id)) {
    return frame_id;
  }
  // 3. if no frame can be evicted, throw WSDB_NO_FREE_FRAME
  WSDB_THROW(WSDB_NO_FREE_FRAME, "Error: NO FREE FRAME");
}

void BufferPoolManager::UpdateFrame(frame_id_t frame_id, file_id_t fid, page_id_t pid)
{
  // 1. if the frame is dirty, flush the page to disk
  Frame &frame = frames_[frame_id];
  Page  *page  = frame.GetPage();
  if (frame.IsDirty()) {
    disk_manager_->WritePage(page->GetFileId(), page->GetPageId(), frame.GetPage()->GetData());
  }
  page_frame_lookup_.erase({page->GetFileId(), page->GetPageId()});
  frame.Reset();
  // 2. update the frame with the new page
  disk_manager_->ReadPage(fid, pid, frame.GetPage()->GetData());
  frame.GetPage()->SetFilePageId(fid, pid);
  // 3. pin the frame in the buffer and the replacer
  frame.Pin();
  replacer_->Pin(frame_id);
  // 4. update the page_frame_lookup_
  page_frame_lookup_[{fid, pid}] = frame_id;
}

auto BufferPoolManager::GetFrame(file_id_t fid, page_id_t pid) -> Frame *
{
  const auto it = page_frame_lookup_.find({fid, pid});
  return it == page_frame_lookup_.end() ? nullptr : &frames_[it->second];
}

}  // namespace wsdb